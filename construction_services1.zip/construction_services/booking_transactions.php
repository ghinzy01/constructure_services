<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $client_id = $_POST['client_id'];
    $service_id = $_POST['service_id'];
    $booking_date = $_POST['booking_date'];
    $hours_rendered = $_POST['hours_rendered'];

    // Check if date is already booked
    $stmt = $conn->prepare("SELECT * FROM bookings WHERE booking_date=?");
    $stmt->bind_param("s", $booking_date);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo "Date already booked!";
    } else {
        // Calculate total amount
        $rate_stmt = $conn->prepare("SELECT hourly_rate FROM services WHERE id=?");
        $rate_stmt->bind_param("i", $service_id);
        $rate_stmt->execute();
        $rate_result = $rate_stmt->get_result();
        $rate_row = $rate_result->fetch_assoc();
        $total_amount = $hours_rendered * $rate_row['hourly_rate'];

        // Insert booking
        $stmt = $conn->prepare("INSERT INTO bookings (client_id, service_id, booking_date, hours_rendered, total_amount) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisdd", $client_id, $service_id, $booking_date, $hours_rendered, $total_amount);
        if ($stmt->execute()) {
            echo "Booking saved successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }
    }
    $stmt->close();
}
?>

<form method="POST">
    Client: <select name="client_id" required>
        <?php
        $result = $conn->query("SELECT * FROM clients");
        while ($row = $result->fetch_assoc()): ?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
        <?php endwhile; ?>
    </select><br>
    Service: <select name="service_id" required>
        <?php
        $result = $conn->query("SELECT * FROM services");
        while ($row = $result->fetch_assoc()): ?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['service_name']; ?></option>
        <?php endwhile; ?>
    </select><br>
    Date: <input type="date" name="booking_date" required><br>
    Hours Rendered: <input type="number" step="0.01" name="hours_rendered" required><br>
    <button type="submit">Book</button>
</form>