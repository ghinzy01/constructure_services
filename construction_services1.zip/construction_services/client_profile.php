<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    if (isset($_POST['edit'])) {
        $id = $_POST['id'];
        $stmt = $conn->prepare("UPDATE clients SET name=?, phone=?, email=?, address=? WHERE id=?");
        $stmt->bind_param("ssssi", $name, $phone, $email, $address, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO clients (name, phone, email, address) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $phone, $email, $address);
    }

    if ($stmt->execute()) {
        echo "Client saved successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
?>

<form method="POST">
    <input type="hidden" name="id" value="<?php echo isset($_GET['edit']) ? $_GET['edit'] : ''; ?>">
    Name: <input type="text" name="name" required><br>
    Phone: <input type="text" name="phone" required><br>
    Email: <input type="email" name="email" required><br>
    Address: <textarea name="address" required></textarea><br>
    <button type="submit" name="<?php echo isset($_GET['edit']) ? 'edit' : 'add'; ?>">Save</button>
</form>