<?php
include 'config.php';

// Check if REQUEST_METHOD is set before using it
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $service_name = $_POST['service_name'] ?? ''; // Prevent undefined key warning
    $hourly_rate = $_POST['hourly_rate'] ?? '';

    if (isset($_POST['delete'])) {
        $id = $_POST['id'] ?? 0;
        $stmt = $conn->prepare("DELETE FROM services WHERE id=?");
        $stmt->bind_param("i", $id);
    } elseif (isset($_POST['edit'])) {
        $id = $_POST['id'] ?? 0;
        $stmt = $conn->prepare("UPDATE services SET service_name=?, hourly_rate=? WHERE id=?");
        $stmt->bind_param("sdi", $service_name, $hourly_rate, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO services (service_name, hourly_rate) VALUES (?, ?)");
        $stmt->bind_param("sd", $service_name, $hourly_rate);
    }

    if ($stmt->execute()) {
        echo "Service saved successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
?>

<form method="POST">
    <input type="hidden" name="id" value="<?php echo $_GET['edit'] ?? ''; ?>">
    
    Service Name: <input type="text" name="service_name" required><br>
    Hourly Rate: <input type="number" step="0.01" name="hourly_rate" required><br>
    
    <button type="submit" name="add">Save</button>
    
    <?php if (isset($_GET['edit'])): ?>
        <button type="submit" name="edit">Update</button>
        <button type="submit" name="delete">Delete</button>
    <?php endif; ?>
</form>
