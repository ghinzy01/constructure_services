<?php
include 'config.php';

$result = $conn->query("
    SELECT clients.name, bookings.booking_date, bookings.total_amount, payments.amount_paid
    FROM bookings
    JOIN clients ON bookings.client_id = clients.id
    LEFT JOIN payments ON bookings.id = payments.booking_id
");

echo "<table border='1'>
    <tr>
        <th>Client</th>
        <th>Date</th>
        <th>Total Amount</th>
        <th>Amount Paid</th>
    </tr>";
while ($row = $result->fetch_assoc()):
    echo "<tr>
        <td>{$row['name']}</td>
        <td>{$row['booking_date']}</td>
        <td>{$row['total_amount']}</td>
        <td>{$row['amount_paid']}</td>
    </tr>";
endwhile;
echo "</table>";
?>